# CalculatorApp-Javascript
Calculator App made using Html ,CSS and Javascript.

# Screen shots
![Screenshot 2023-09-14 115331](https://github.com/darsh5921/CalculatorApp-Javascript/assets/104684690/0a580d3f-5edb-4f3b-a8e3-c71c1777d2c0)

![Screenshot 2023-09-14 115022](https://github.com/darsh5921/CalculatorApp-Javascript/assets/104684690/f301ed35-02ad-450f-8551-01cea96b00fa)
